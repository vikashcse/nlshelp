const { Schema, model } = require("mongoose");
const helpformmessages = new Schema(
    {
        user_name: {
            type: String
        },
        last_name: {
            type: String
        },
        email_id: {
            type: String
        },
        phone_number: {
            type: String
        },
        company_name: {
            type: String
        },
        comapny_website: {
            type: String
        },
        message_body: {
            type: String
        },
        message_subject: {
            type: String
        },
        problem_Category: {
            type: String
        },
        hardware_software: {
            type: String
        },
        priority_level: {
            type: String
        },
        date:{
            type:Date
        },
        messageList:[],
        adminemail_id: {
            type: String
        },
        unread:{
            type:Boolean
        },
        status:{
            type:Number
        },
        fromsite: {
            type: String
        },
        publicIp: {
            type: String
        },
        ipDetails:{},
        privateIp: {
            type: String
        },
        hostName: {
            type: String
        },
        deviceName: {
            type: String
        },
        from_address: {
            type: String
        },
        isReply:{
            type:Boolean
        },
        adminNotes: {
            type: String
        },
        mesgStatus: {
            type: String
        },
    }
);

module.exports = model("helpformmessages", helpformmessages);
