const { Schema, model } = require("mongoose");

const Users = new Schema(
    {
        created_date: {
            type: Date
        },
        email_id: {
            type: String,
            required: true
        },
        first_name: {
            type: String,
            required: true
        },
        last_name: {
            type: String,
            required: true
        },
        password: {
            type: String,
            required: true
        },
        phone: {
            type: Number,
            required: true
        },
        user_type: {
            type: String,
            required: true
        },
        dateofbirth: {
            type: String,
            required: true
        },
        admin_type: {
            type: String,
        },
        user_status: {
            type: String,
            required: true
        },

    },
    { timestamps: true }
);

module.exports = model("Users", Users);