const { Schema, model } = require("mongoose");

const popupformmessages = new Schema(
    {
        email_id: {
            type: String
        },
        message_subject: {
            type: String
        },
        user_name: {
            type: String
        },
        ipDetails: {
        },
        
        messageList:[{
            email_id: {
                type: String
            },
            message_body: {
                type: String
            },
            message_subject: {
                type: String
            },
            user_name: {
                type: String
            },
            phone_number: {
                type: String
            },
            fromsite: {
                type: String
            },
            publicIp: {
                type: String
            },
            ipDetails: {
            },
            privateIp: {
                type: String
            },
            hostName: {
                type: String
            },
            date:{
                type:String 
            },
            adminemail_id: {
                type: String
            },
            unread:{
                type:Boolean,
                default:true
            },
            from_address: {
                type: String
            },
            deviceName: {
                type: String
            },
            isReply:{
                type:Boolean,
                default:false
            },
            status:{
                type:Number
            },
             adminNotes: {
                type: String
            },
            mesgStatus: {
                type: String
            },
        }]
    })

module.exports = model("popupformmessages", popupformmessages);