const { Schema, model } = require("mongoose");

const tasklist = new Schema(
    {
        full_name: {
            type: String,
        },
        phone: {
            type: String,
        },
        email_id: {
            type: String,
        },
        task_name: {
            type: String,
        },
        assigned_to: {
            type: String,
        },
        start_date: {
            type: Date,
        },
        resolution_date: {
            type: Date,
        },
        message: {
            type: String,
        },
        problem_Category: {
            type: String,
        },
        priority_level: {
            type: String,
        },
        resolution_status: {
            type: String,
        },
        progress: {
            type: String,
        }

    }
);

module.exports = model("tasklist", tasklist);