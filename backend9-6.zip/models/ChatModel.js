const { Schema, model } = require("mongoose");
const chatmessages = new Schema(
    {
        userid: {
            type: String,
            required: true
        },
        fullName: {
            type: String,
            required: true
        },
        phoneNo: {
            type: Number,
            required: true
        },
        messageList: [{
            Name: String,
            Message: String
        }]
    }
);

module.exports = model("chatmessages", chatmessages);
