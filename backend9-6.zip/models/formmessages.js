const { Schema, model } = require("mongoose");

const formmessages = new Schema(
    {
        email_id: {
            type: String,
            required: true
        },
        message_body: {
            type: String,
            required: true
        },
        message_subject: {
            type: String,
            required: true
        },
        user_name: {
            type: String,
            required: true
        },
        phone_number: {
            type: String,
            required: true
        },
        date:{type:Date},
        messageList:[],
        adminemail_id: {
            type: String,
            required: true
        },
        unread:{type:Boolean},
        status :{type:Number},
        romsite: {
            type: String,
            required: true
        },
        publicIp: {
            type: String,
            required: true
        },
        ipDetails:{},
        privateIp: {
            type: String,
            required: true
        },
        hostName: {
            type: String,
            required: true
        },
        deviceName: {
            type: String,
            required: true
        },
        how_you_know: {
            type: String,
            required: true
        },
        last_name: {
            type: String,
            required: true
        },
        use_device: {
            type: String,
            required: true
        },
        company_name: {
            type: String,
            required: true
        },
        comapny_website: {
            type: String,
            required: true
        },
        address1: {
            type: String,
            required: true
        },
        address2: {
            type: String,
            required: true
        },
        city: {
            type: String,
            required: true
        },
        region: {
            type: String,
            required: true
        },
        zipcode: {
            type: String,
            required: true
        },
        select_country: {
            type: String,
            required: true
        },
        from_address: {
            type: String,
            required: true
        },
        isReply:{
            type:Boolean
        },
        adminNotes: {
            type: String,
            required: true
        },
        mesgStatus: {
            type: String,
            required: true
        }
    }
)

module.exports = model("formmessages", formmessages);