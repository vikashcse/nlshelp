const popupformmessages = require('../models/popupformmessages')
const eventt =new Date().toISOString()


const validateEmail = async (email_id) => {
    let user = await popupformmessages.findOne({ email_id:email_id });
    return user ? false : true;
  };



const newPopUp=(req,res)=>{
    const newPopup= new popupformmessages({
        email_id:req.body.email_id,
        user_name:req.body.user_name,
        message_subject:req.body.message_subject,
        ipDetails:req.body.ipDetails,
        messageList:[{...req.body,date:eventt}]
    
      })
    
      newPopup.save((err,docs)=>{
        if(!err){
          //console.log(docs)
          res.json({
            message:"SuccessFully Submited",
            success:true,
            data:docs
          })
        }
        else{
          res.send(err)
        }
      })
}

const existingPopUp= (req,res)=>{
    popupformmessages.findOneAndUpdate({email_id:req.body.email_id},{
    $push: {
        messageList: [{
            ...req.body,
            date:eventt
        }]
      }
    },(err,docs)=>{
        if(!err){
            res.json({
                message:"SuccessFully Submited",
                success:true
            })
        }
    })
}

module.exports={
    newPopUp,
    existingPopUp,
    validateEmail
};