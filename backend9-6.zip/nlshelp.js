const { base64encode, base64decode } = require('nodejs-base64');
const express = require('express')
const path = require('path')
const bodyParser = require('body-parser')
const { connect } = require("mongoose");
const { success, error } = require("consola");
const { DB, PORT } = require("./config");
var cors = require('cors')
const chatmessages = require('./models/ChatModel')
const Users = require('./models/users')
const popupformmessages = require('./models/popupformmessages')
const formmessages =require('./models/formmessages')
const helpformmessages=require('./models/helpformmessages')
const tasklist=require('./models/tasklist')


const {newPopUp,existingPopUp,validateEmail} = require('./Utils/Utils')

const app = express()


app.use(express.static('dist'))
app.use(bodyParser.urlencoded({ extended: false }))
// parse application/json
app.use(bodyParser.json())
app.use(cors())


app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'dist/index.html'));
})


app.get('/session/login', (req, res) => {
  res.sendFile(path.join(__dirname, 'dist/index.html'));
})
app.get('/home/forms', (req, res) => {
  res.sendFile(path.join(__dirname, 'dist/index.html'));
})
app.get('/home/popup', (req, res) => {
  res.sendFile(path.join(__dirname, 'dist/index.html'));
})
app.get('/home/helpForm', (req, res) => {
  res.sendFile(path.join(__dirname, 'dist/index.html'));
})
app.get('/home/healthForm', (req, res) => {
  res.sendFile(path.join(__dirname, 'dist/index.html'));
})
app.get('/home/chats', (req, res) => {
  res.sendFile(path.join(__dirname, 'dist/index.html'));
})
app.get('/home/task', (req, res) => {
  res.sendFile(path.join(__dirname, 'dist/index.html'));
})
app.get('/session/nls', (req, res) => {
  res.sendFile(path.join(__dirname, 'dist/index.html'));
})


app.post('/api/login', (req, res) => {
  console.log(req.body)
  let email = base64decode(req.body.EmailId);
  let Password=base64decode(req.body.Password);
  console.log("email   "+email)
  Users.find({ email_id:email}, (err, docs) => {
    console.log(docs)
    console.log(docs.length)
    if (docs.length>0) {
      if(docs[0].password==Password){
        res.json({
          "isSucess": true,
          "message": "Success",
          "data": docs[0]
        })
      }
      else if(docs[0].password!=Password){
        res.json({
          "isSucess": false,
          "message": "Wrong Credentials"
        })
      }
      else{
        res.json({
          "isSucess": false,
          "message": `Error :- ${err}`
        })
      }
    }
    else if(docs.length==0) {
      res.json({
        "isSucess": false,
        "message": "Wrong Credentials."
      })
    }
    else {
      res.json({
        "isSucess": false,
        "message": "fail"
      })
    }

  })
})

app.get('/api/formsreply', (req, res) => {
  formmessages.find((err,docs)=>{
    if(!err){
      res.send(docs)
    }
  })
})

app.get('/api/helpform', (req, res) => {
  helpformmessages.find((err,docs)=>{
    if(!err){
      res.send(docs)
    }
  })
})
app.get('/api/healthform', (req, res) => {
  helpformmessages.find((err,docs)=>{
    if(!err){
      res.send(docs)
    }
  })
})
app.get('/api/taskTable', (req, res) => {
  tasklist.find((err,docs)=>{
    console.log(docs)
    if(!err){
      res.send(docs)
    }
    else{
      console.log(err)
    }
  })
})

app.get('/api/popupform',(req,res)=>{
  popupformmessages.find((err,docs)=>{
    if(!err){
      res.send(docs)
    }
    else{
      res.send(err)
    }
  })
})

app.get('/api/chat', (req, res) => {
  console.log("chat")
  chatmessages.find((err, docs) => {
    res.send(docs)
  })
})

app.get('/users', (req, res) => {
  console.log("users")
  Users.find((err, docs) => {
    res.send(docs)
  })
})

app.post('/api/chat', (req, res) => {
  console.log(req.body)
  let decoded = base64decode(req.body.EmailId);
  console.log(decoded)
})


app.post("/api/popupform",async (req,res)=>{
  //console.log(await validateEmail(req.body.email_id))
  if(!await validateEmail(req.body.email_id)){
    existingPopUp(req,res)
  }
  else if(await validateEmail(req.body.email_id)){
    newPopUp(req,res)
  }
})


app.post("/api/deletPopup",(req,res)=>{
  popupformmessages.findByIdAndDelete({_id:req.body._id},(err,docs)=>{
    console.log(docs)
    if(docs){
      res.json({
        message:"Delet Successfull",
        sucess:true
      })
    }
    else if(!docs){
      res.json({
        message:"No Document To Delete",
        sucess:false
      })
    }
    else{
      res.json({
        message:`Error:- ${err}`,
        sucess:false
      })
    }
  })
})


const startApp = async () => {
  try {
    // Connection With DB
    await connect(DB, {
      useFindAndModify: false,
      useUnifiedTopology: true,
      useNewUrlParser: true
    });

    success({
      message: `Successfully connected with the Database \n${DB}`,
      badge: true
    });

    // Start Listenting for the server on PORT
    app.listen(3007, () =>
      success({ message: `Server started on PORT ${PORT}`, badge: true })
    );
  } catch (err) {
    error({
      message: `Unable to connect with Database \n${err}`,
      badge: true
    });
    startApp();
  }
};


startApp()